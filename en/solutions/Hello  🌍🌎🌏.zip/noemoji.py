# Add ASCII art alternatives
# Before emoji we used emoticons made from characters

world = 'o'
python = '~~~-<'
happy = ':-)
heart = '♡' # or '<3'
star = '☆'
sparkles = '✺'
silly = ';)'
sums = '+-*/'
hundred = '100!'
plead = '◔◔'
fire = '/\'
books = '≣'
rainbow = '⌒'

